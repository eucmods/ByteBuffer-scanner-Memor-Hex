package com.kmods;
/*
CODE BY CORINGA MODZ

TELEGRAM @CoRingaModzYT

*/


import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.Signature;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.provider.Settings.Secure;
import android.util.Base64;
import android.widget.Toast;
import com.miniclip.eightballpool.EightBallPoolActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class KMODsActivity extends Activity {
    String content = "";

    private static class Crypto {
        private Cipher value_decode = null;
        private Cipher value_encode = null;

        Crypto(String str) {
            try {
                this.value_encode = Cipher.getInstance("AES/CBC/PKCS5Padding");
                this.value_decode = Cipher.getInstance("AES/CBC/PKCS5Padding");
                byte[] bArr = new byte[this.value_encode.getBlockSize()];
                System.arraycopy("fldsjfodasjifudslfjdsaofshaufihadsf".getBytes(), 0, bArr, 0, this.value_encode.getBlockSize());
                IvParameterSpec ivParameterSpec = new IvParameterSpec(bArr);
                MessageDigest instance = MessageDigest.getInstance("SHA-256");
                instance.reset();
                SecretKeySpec secretKeySpec = new SecretKeySpec(instance.digest(str.getBytes("UTF-8")), "AES/CBC/PKCS5Padding");
                this.value_encode.init(1, secretKeySpec, ivParameterSpec);
                this.value_decode.init(2, secretKeySpec, ivParameterSpec);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private String decode(String str) {
            try {
                return new String(this.value_decode.doFinal(Base64.decode(str, 8)), "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
                return "";
            }
        }

      
        public String encode(String str) {
            try {
                return Base64.encodeToString(this.value_encode.doFinal(str.getBytes("UTF-8")), 8);
            } catch (Exception e) {
                e.printStackTrace();
                return "";
            }
        }
    }

 
    public void Update() {
        new AsyncTask<Void, Void, String>() {
            private ProgressDialog progDlg;

            /* access modifiers changed from: protected */
            public String doInBackground(Void... voidArr) {
                Signature[] signatureArr;
                try {
                    for (Signature signature : KMODsActivity.this.getPackageManager().getPackageInfo(KMODsActivity.this.getPackageName(), 64).signatures) {
                        MessageDigest instance = MessageDigest.getInstance("SHA");
                        instance.update(signature.toByteArray());
                        if (!"s1EJPVnoeHa48PcjXjNTbWyCSM0=".equals(Base64.encodeToString(instance.digest(), 0).trim())) {
                            KMODsActivity.this.finish();
                        }
                    }
                    if (!KMODsActivity.this.isInternetAvailable()) {
                        return "?";
                    }
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL("https://kp7742.github.io/Update.html").openConnection().getInputStream()));
                    String str = "";
                    while (true) {
                        String readLine = bufferedReader.readLine();
                        if (readLine != null) {
                            StringBuilder sb = new StringBuilder();
                            KMODsActivity kMODsActivity = KMODsActivity.this;
                            kMODsActivity.content = sb.append(kMODsActivity.content).append(readLine).toString();
                        } else {
                            bufferedReader.close();
                            return "1";
                        }
                    }
                } catch (Exception e) {
                    return "?";
                }
            }

          
            public void onPostExecute(String str) {
                this.progDlg.dismiss();
                if (str.equals("?")) {
                    Builder builder = new Builder(KMODsActivity.this);
                    builder.setTitle("Attention!").setMessage("You Are Not Connect With Internet!, Please connect to internet to continue.");
                    builder.setNeutralButton("Ok", new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            KMODsActivity.this.finish();
                        }
                    }).setCancelable(false);
                    builder.create();
                    builder.show();
                    return;
                }
                String access$300 = KMODsActivity.getUniqueId(KMODsActivity.this);
                if (KMODsActivity.this.content.contains("vip=true")) {
                    KMODsActivity.this.startActivity(new Intent(KMODsActivity.this, EightBallPoolActivity.class));
                    if (!KMODsActivity.this.isServiceRunning()) {
                        new Handler().postDelayed(new Runnable() {
                            public void run() {
                                KMODsActivity.this.startService(new Intent(KMODsActivity.this, FloatingActivity.class));
                            }
                        }, 1000);
                    }
                    Toast.makeText(KMODsActivity.this, "!!Modded By KMODs!!", 1).show();
                    KMODsActivity.this.finish();
                    return;
                }
                Builder builder2 = new Builder(KMODsActivity.this);
                builder2.setTitle("Error!").setMessage("This Mod Disable right now. Try again later");
                builder2.setNeutralButton("Ok", new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        KMODsActivity.this.finish();
                    }
                }).setCancelable(false);
                builder2.create();
                builder2.show();
            }
            public void onPreExecute() {
                ProgressDialog progressDialog = new ProgressDialog(KMODsActivity.this);
                this.progDlg = progressDialog;
                progressDialog.setMessage("Info Updating...");
                this.progDlg.setCancelable(false);
                this.progDlg.show();
            }
        }.execute(new Void[0]);
    }

    public static String getDeviceName() {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        return str2.startsWith(str) ? str2 : str + " " + str2;
    }
    private static String getGsfAndroidId(Context context) {
        ? r2 = 0;
        Cursor query = context.getContentResolver().query(Uri.parse("content://com.google.android.gsf.gservices"), r2, r2, new String[]{"android_id"}, r2);
        if (!query.moveToFirst() || query.getColumnCount() < 2) {
            return r2;
        }
        try {
            return Long.toHexString(Long.parseLong(query.getString(1)));
        } catch (NumberFormatException e) {
            return r2;
        }
    }

  
    public static String getUniqueId(Context context) {
        String replace = (getDeviceName() + Secure.getString(context.getApplicationContext().getContentResolver(), "android_id") + getGsfAndroidId(context) + Build.HARDWARE).replace(" ", "");
        return new Crypto(replace).encode(replace);
    }

   
    public boolean isInternetAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

   
    public boolean isServiceRunning() {
        for (RunningServiceInfo runningServiceInfo : ((ActivityManager) getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (FloatingActivity.class.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private void startGame() {
        new Handler().postDelayed(new Runnable() {
            public void run() {
                KMODsActivity.this.Update();
            }
        }, 2000);
    }

    public String getOS() {
        return "Android OS " + VERSION.RELEASE + " / API-" + VERSION.SDK_INT;
    }
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i != 1) {
            return;
        }
        if (VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            Update();
        } else {
            Toast.makeText(this, "Please allow this permission, so Patcher could be drawn.", 1).show();
        }
    }
    public void onCreate(Bundle bundle) {
        Signature[] signatureArr;
        super.onCreate(bundle);
        try {
            for (Signature signature : getPackageManager().getPackageInfo(getPackageName(), 64).signatures) {
                MessageDigest instance = MessageDigest.getInstance("SHA-384");
                instance.update(signature.toByteArray());
                if (!"1glSi8l2CZHMvwOK6GjzI5n2xgjymW0dZsC6gT3MbUEz1yQ72BGQrjxOTxvTKQgw".equals(Base64.encodeToString(instance.digest(), 0).trim())) {
                    finish();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            Update();
        } else {
            startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 1);
        }
    }
}
