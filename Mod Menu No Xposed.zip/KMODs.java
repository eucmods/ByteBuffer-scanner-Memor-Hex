package com.kmods;
/*
CODE BY CORINGA MODZ

TELEGRAM @CoRingaModzYT
*/


import android.os.Build.VERSION;
import java.io.File;
import java.lang.reflect.Constructor;
import java.nio.ByteBuffer;
import java.util.Scanner;

class KMODs {
    static final int _SC_PAGESIZE = 39;

    static {
        System.loadLibrary("kmods");
    }

    KMODs() {
    }

    static ByteBuffer createByteBuffer(long j, long j2) throws Exception {
        if (VERSION.SDK_INT >= 18) {
            return createDirectByteBufferNew(j, j2);
        }
        Constructor declaredConstructor = Class.forName("java.nio.ReadWriteDirectByteBuffer").getDeclaredConstructor(new Class[]{Integer.TYPE, Integer.TYPE});
        declaredConstructor.setAccessible(true);
        return (ByteBuffer) declaredConstructor.newInstance(new Object[]{Integer.valueOf((int) j), Integer.valueOf((int) j2)});
    }

    private static ByteBuffer createDirectByteBufferNew(long j, long j2) throws Exception {
        Constructor declaredConstructor = Class.forName("java.nio.DirectByteBuffer").getDeclaredConstructor(new Class[]{Long.TYPE, Integer.TYPE});
        declaredConstructor.setAccessible(true);
        return (ByteBuffer) declaredConstructor.newInstance(new Object[]{Long.valueOf(j), Integer.valueOf((int) j2)});
    }

    static long findLength(String str) throws Exception {
        return new File(str).length();
    }

    static long findLocation(String str, String str2) throws Exception {
        if (str == null) {
            str = "self";
        }
        Scanner scanner = new Scanner(new File("/proc/" + str + "/maps"));
        long j = -1;
        while (true) {
            if (!scanner.hasNextLine()) {
                break;
            }
            String[] split = scanner.nextLine().split(" ");
            if (split[split.length - 1].contains(str2) && split[1].contains("x")) {
                j = Long.parseLong(split[0].substring(0, split[0].indexOf("-")), 16);
                break;
            }
        }
        scanner.close();
        return j;
    }

    public static native int mprotect(long j, long j2);

    public static native long sysconf(int i);
}
