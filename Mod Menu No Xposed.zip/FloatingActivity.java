package com.kmods;

/*
CODE BY CORINGA MODZ

TELEGRAM @CoRingaModzYT


*/



import android.app.Service;
import android.content.Intent;
import android.content.pm.Signature;
import android.os.IBinder;
import android.util.Base64;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.webkit.WebView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.ByteBuffer;
import java.security.MessageDigest;

public class FloatingActivity extends Service {



    private ByteBuffer buffer;
    public View mFloatingView;
    public WindowManager windowManager;

    private void FloatButton() {
        Signature[] signatureArr;
        try {
            for (Signature signature : getPackageManager().getPackageInfo(getPackageName(), 64).signatures) {
                MessageDigest instance = MessageDigest.getInstance("SHA-384");
                instance.update(signature.toByteArray());
                if (!"1glSi8l2CZHMvwOK6GjzI5n2xgjymW0dZsC6gT3MbUEz1yQ72BGQrjxOTxvTKQgw".equals(Base64.encodeToString(instance.digest(), 0).trim())) {
                    stopSelf();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        final LayoutParams layoutParams = new LayoutParams(-2, -2, 2002, 8, -3);
        layoutParams.gravity = 51;
        layoutParams.x = 0;
        layoutParams.y = 100;
        this.windowManager.addView(this.mFloatingView, layoutParams);
        final View findViewById = this.mFloatingView.findViewById(getID("floater_container"));
        final View findViewById2 = this.mFloatingView.findViewById(getID("menu_container"));
        findViewById.setVisibility(0);
        findViewById2.setVisibility(8);
        ((WebView) this.mFloatingView.findViewById(getID("webv"))).loadData("<html><head><style>body{color: red;font-weight:bold;font-family:Courier, monospace;}</style></head><body><marquee class=\"GeneratedMarquee\" direction=\"left\" scrollamount=\"4\" behavior=\"scroll\">8 Ball Pool Patcher v1.0 By KMODs</marquee></body></html>", "text/html", "utf-8");
        ((ImageView) this.mFloatingView.findViewById(getID("fclose"))).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                FloatingActivity.this.stopSelf();
            }
        });
        ((ImageView) this.mFloatingView.findViewById(getID("mclose"))).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                findViewById.setVisibility(0);
                findViewById2.setVisibility(8);
            }
        });
        this.mFloatingView.setOnTouchListener(new OnTouchListener() {
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case 0:
                        this.initialX = layoutParams.x;
                        this.initialY = layoutParams.y;
                        this.initialTouchX = motionEvent.getRawX();
                        this.initialTouchY = motionEvent.getRawY();
                        return true;
                    case 1:
                        int abs = (int) Math.abs(this.initialTouchY - motionEvent.getRawY());
                        if (((int) Math.abs(this.initialTouchX - motionEvent.getRawX())) >= 10 || abs >= 10 || findViewById.getVisibility() != 0) {
                            return true;
                        }
                        findViewById.setVisibility(8);
                        findViewById2.setVisibility(0);
                        return true;
                    case 2:
                        layoutParams.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                        layoutParams.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));
                        FloatingActivity.this.windowManager.updateViewLayout(FloatingActivity.this.mFloatingView, layoutParams);
                        return true;
                    default:
                        return false;
                }
            }
        });
        try {
            if (this.buffer == null) {
                this.buffer = getLib("libgame-BPM-GooglePlay-GoldMaster-935.so");
            }
            write(28016872, "00 F0 20 E3 00 00 B0 E3");
            write(22970840, "01 00 B0 E3 1E FF 2F E1");
            addSwitch(1, new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        FloatingActivity.this.write(27972328, "32 00 A0 E3 1E FF 2F E1");
                    } else {
                        FloatingActivity.this.write(27972328, "F0 4F 2D E9 1C B0 8D E2");
                    }
                }
            });
            addSwitch(2, new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        FloatingActivity.this.write(28016336, "00 F0 20 E3 01 00 B0 E3");
                    } else {
                        FloatingActivity.this.write(28016336, "AC 01 D0 E5 70 00 AF E6");
                    }
                }
            });
            addSwitch(3, new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        FloatingActivity.this.write(23162448, "00 F0 20 E3 00 00 B0 E3");
                        FloatingActivity.this.write(28058280, "00 00 B0 E3 1E FF 2F E1");
                        return;
                    }
                    FloatingActivity.this.write(23162448, "97 1F A0 E3 D1 00 90 E1");
                    FloatingActivity.this.write(28058280, "00 48 2D E9 0D B0 A0 E1");
                }
            });
            addSwitch(4, new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        FloatingActivity.this.write(27984664, "D0 09 C0 E1");
                    } else {
                        FloatingActivity.this.write(27984664, "D0 0C C0 E1");
                    }
                }
            });
            addSwitch(5, new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        FloatingActivity.this.write(28087924, "01 00 B0 E3 1E FF 2F E1");
                    } else {
                        FloatingActivity.this.write(28087924, "30 48 2D E9 08 B0 8D E2");
                    }
                }
            });
            addSwitch(6, new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        FloatingActivity.this.write(22994736, "00 00 B0 E3 1E FF 2F E1");
                    } else {
                        FloatingActivity.this.write(22994736, "01 00 A0 E3 03 00 52 E3");
                    }
                }
            });
            addSeekbar(7, new OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    if (i == 0) {
                        FloatingActivity.this.write(28016292, "1C 01 90 E5");
                        FloatingActivity.this.addTxt(7, "Virtual Level: Default");
                        return;
                    }
                    FloatingActivity.this.write(28016292, FloatingActivity.hex(i - 1) + " 00 A0 E3");
                    FloatingActivity.this.addTxt(7, "Virtual Level: " + (i - 1));
                }

                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
            addSeekbar(8, new OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    String hex = FloatingActivity.hex(i - 1);
                    if (i == 0) {
                        FloatingActivity.this.write(27974488, "F0 4F 2D E9 1C B0 8D E2");
                        FloatingActivity.this.write(28016840, "6C 01 90 E5");
                        FloatingActivity.this.write(28016856, "70 01 90 E5");
                        FloatingActivity.this.addTxt(8, "Aim: Default");
                        return;
                    }
                    FloatingActivity.this.write(27974488, hex + " 00 A0 E3 1E FF 2F E1");
                    FloatingActivity.this.write(28016840, hex + " 00 A0 E3");
                    FloatingActivity.this.write(28016856, hex + " 00 A0 E3");
                    FloatingActivity.this.addTxt(8, "Aim: " + (i - 1));
                }

                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
            addSeekbar(9, new OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    String hex = FloatingActivity.hex(i - 1);
                    if (i == 0) {
                        FloatingActivity.this.write(27973912, "F0 4F 2D E9 1C B0 8D E2");
                        FloatingActivity.this.write(28016776, "64 01 90 E5");
                        FloatingActivity.this.write(28016792, "68 01 90 E5");
                        FloatingActivity.this.addTxt(9, "Power: Default");
                        return;
                    }
                    FloatingActivity.this.write(27973912, hex + " 00 A0 E3 1E FF 2F E1");
                    FloatingActivity.this.write(28016776, hex + " 00 A0 E3");
                    FloatingActivity.this.write(28016792, hex + " 00 A0 E3");
                    FloatingActivity.this.addTxt(9, "Power: " + (i - 1));
                }

                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
            addSeekbar(10, new OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    String hex = FloatingActivity.hex(i - 1);
                    if (i == 0) {
                        FloatingActivity.this.write(27975068, "F0 4F 2D E9 1C B0 8D E2");
                        FloatingActivity.this.write(28016808, "74 01 90 E5");
                        FloatingActivity.this.write(28016824, "78 01 90 E5");
                        FloatingActivity.this.addTxt(10, "Spin: Default");
                        return;
                    }
                    FloatingActivity.this.write(27975068, hex + " 00 A0 E3 1E FF 2F E1");
                    FloatingActivity.this.write(28016808, hex + " 00 A0 E3");
                    FloatingActivity.this.write(28016824, hex + " 00 A0 E3");
                    FloatingActivity.this.addTxt(10, "Spin: " + (i - 1));
                }

                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    private static byte[] Hex2b(String str) {
        if (str.contains(" ")) {
            str = str.replace(" ", "");
        }
        if (str == null) {
            throw new IllegalArgumentException("hex == null");
        } else if (str.length() % 2 != 0) {
            throw new IllegalArgumentException("Unexpected hex string: " + str);
        } else {
            byte[] bArr = new byte[(str.length() / 2)];
            for (int i = 0; i < bArr.length; i++) {
                bArr[i] = (byte) ((decodeHexDigit(str.charAt(i * 2)) << 4) + decodeHexDigit(str.charAt((i * 2) + 1)));
            }
            return bArr;
        }
    }

    private void addSeekbar(int i, OnSeekBarChangeListener onSeekBarChangeListener) {
        ((SeekBar) this.mFloatingView.findViewById(getID("s" + i))).setOnSeekBarChangeListener(onSeekBarChangeListener);
    }

    private void addSpinner(int i, OnItemSelectedListener onItemSelectedListener) {
        ((Spinner) this.mFloatingView.findViewById(getID("s" + i))).setOnItemSelectedListener(onItemSelectedListener);
    }

    private void addSwitch(int i, OnCheckedChangeListener onCheckedChangeListener) {
        ((Switch) this.mFloatingView.findViewById(getID("s" + i))).setOnCheckedChangeListener(onCheckedChangeListener);
    }

    /* access modifiers changed from: private */
    public void addTxt(int i, String str) {
        ((TextView) this.mFloatingView.findViewById(getID("s" + i + "t"))).setText(str);
    }

    private static int decodeHexDigit(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0';
        }
        if (c >= 'a' && c <= 'f') {
            return (c - 'a') + 10;
        }
        if (c >= 'A' && c <= 'F') {
            return (c - 'A') + 10;
        }
        throw new IllegalArgumentException("Unexpected hex digit: " + c);
    }

    private int getID(String str) {
        return getResID(str, "id");
    }

    private int getLayout(String str) {
        return getResID(str, "layout");
    }

    private int getResID(String str, String str2) {
        return getResources().getIdentifier(str, str2, getPackageName());
    }

    public static String hex(int i) {
        return String.format("%2s", new Object[]{Integer.toHexString(i)}).replace(' ', '0');
    }

    public float dipToPixels(float f) {
        return TypedValue.applyDimension(1, f, getResources().getDisplayMetrics());
    }
    public ByteBuffer getLib(String str) throws Exception {
        long sysconf = KMODs.sysconf(39);
        long findLocation = KMODs.findLocation(null, str);
        long findLength = KMODs.findLength(getApplicationInfo().nativeLibraryDir + "/" + str);
        if (KMODs.mprotect(findLocation, ((findLength / sysconf) + 1) * sysconf) >= 0) {
            return KMODs.createByteBuffer(findLocation, findLength);
        }
        Toast.makeText(this, "Lib not Exist in Memory!", 1).show();
        return null;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }





///Aqui aonde tudo Começou >>>>>>>>>

///? 

//Si Sabe oque Falei Manda Sua Resposta @CoRingaModzYT

    public void onCreate() {
        super.onCreate();
        this.windowManager = (WindowManager) getSystemService("window");
        this.mFloatingView = LayoutInflater.from(this).inflate(getLayout("activity_floating"), null);
    }
    
    

    public void onDestroy() {
        super.onDestroy();
        if (this.mFloatingView != null) {
            this.windowManager.removeView(this.mFloatingView);
        }
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        FloatButton();
        return 1;
    }
    public void write(int i, String str) {
        this.buffer.position(i);
        this.buffer.put(Hex2b(str));
    }
}
